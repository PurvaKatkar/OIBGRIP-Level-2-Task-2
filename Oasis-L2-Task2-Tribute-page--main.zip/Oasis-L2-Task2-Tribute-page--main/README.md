# Oasis-L2-Task2-Tribute-page-
I am build a Tribute page using HTML, CSS. I am build tribute page on  Mahatma Gandhi and his life timeline.
